export { StageLogo } from "./stageLogo";
