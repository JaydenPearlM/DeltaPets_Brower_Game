INSERT INTO public.game_config (key, value) VALUES
  ('stat_rules', '{"base_total": 25, "points_per_level": 1, "max_level": 100}');

-- Remove the UPDATE statement entirely